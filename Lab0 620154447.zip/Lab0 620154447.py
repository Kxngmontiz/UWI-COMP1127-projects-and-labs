def squareNum1(a):
    " " " function to square a number" " "
    square = a * a
    print (square)

def squareNum2(a):
    " " " function to square a number" " "
    square = a * a
    return square

def mystery (num):
# This function takes a number as input and doubles it and adds 2 to it
    num = num + 2
    newnum = num + 2
    return newnum
